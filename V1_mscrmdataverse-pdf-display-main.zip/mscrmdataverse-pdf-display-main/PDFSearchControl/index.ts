import { IInputs, IOutputs } from "./generated/ManifestTypes";

export class DynamicPdfViewer implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    private _container: HTMLDivElement;
    private _context: ComponentFramework.Context<IInputs>;
    private _notifyOutputChanged: () => void;

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: ComponentFramework.Dictionary,
        container: HTMLDivElement
    ): void {
        this._context = context;
        this._notifyOutputChanged = notifyOutputChanged;
        this._container = container;

        this.renderPdf();
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        this._context = context;
        this.renderPdf();
    }

    private async renderPdf(): Promise<void> {
        const entityId = (this._context.mode as any).contextInfo?.entityId;
        const entityType = (this._context.mode as any).contextInfo?.entityTypeName;
        const fileColumn = this._context.parameters.fileColumnName.raw;

        if (!entityId || !entityType) {
            this._container.innerHTML = "<p>No record context found.</p>";
            return;
        }
        if (!fileColumn) {
            this._container.innerHTML = "<p>No file column specified.</p>";
            return;
        }

        this._container.innerHTML = "<p>Loading PDF...</p>";

        try {
            const clientUrl = Xrm.Utility.getGlobalContext().getClientUrl();
            const fileUrl = `${clientUrl}/api/data/v9.0/${entityType}(${entityId})/${fileColumn}/$value`;

            const response = await fetch(fileUrl, {
                method: "GET",
                headers: { "Accept": "application/pdf" },
                credentials: "include"
            });

            if (!response.ok) {
                this._container.innerHTML = `<p>No file found on column <strong>${fileColumn}</strong>.</p>`;
                return;
            }

            const blob = await response.blob();
            const base64Pdf = await this.blobToBase64(blob);
            const pdfSrc = `data:application/pdf;base64,${base64Pdf}`;

            const iframe = document.createElement("iframe");
            iframe.src = pdfSrc;
            iframe.width = "100%";
            iframe.height = "600px";
            iframe.style.border = "1px solid #ccc";
            iframe.style.borderRadius = "4px";

            this._container.innerHTML = "";
            this._container.appendChild(iframe);
        } catch (error: unknown) {
            if (error instanceof Error) {
                this._container.innerHTML = `<p>Error loading PDF: ${error.message}</p>`;
            } else {
                this._container.innerHTML = `<p>An unexpected error occurred.</p>`;
            }
        }
    }

    private blobToBase64(blob: Blob): Promise<string> {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                const dataUrl = reader.result as string;
                const base64 = dataUrl.split(",")[1];
                resolve(base64);
            };
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });
    }

    public getOutputs(): IOutputs {
        return {};
    }

    public destroy(): void {
        // Cleanup if needed
    }
}
