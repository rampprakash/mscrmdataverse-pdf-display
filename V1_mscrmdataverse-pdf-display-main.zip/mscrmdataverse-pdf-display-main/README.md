# mscrmdataverse-pdf-display
This PCF control allows users to view PDF documents stored in file columns on Account records directly within a model-driven form. When the form loads, the control automatically identifies the related record and presents the associated PDF, giving users immediate access to important documentation without navigating away or triggering a download.
